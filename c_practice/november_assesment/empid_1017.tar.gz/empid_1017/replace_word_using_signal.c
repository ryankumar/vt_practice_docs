#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pthread.h>
#include<signal.h>

void * fun(void * arg);
void * fun1(void * arg);
int fd;
pthread_t thread1,thread2;
char *revptr=NULL;
char *userbuf=NULL;
char buffer[30];
int count=0;
//  string comparision with case insensitive.
// success :return 0 ,  fail:return 1
int stricmp(char *str1,char *str2)
{
	int flag=0;
	int i=0;
	while(str1[i] || str2[i])
	{
		if((str1[i]-str2[i]==32) || (str2[i]-str1[i])==32 || (str1[i]==str2[i]))
			flag=1;
		else
			return  1;
		i++;
	}
	if(flag)
		return 0;
	else return 1;
}

//  string reverse
char * strrev(char *str)
{
	int i=0,j,l;
	char temp;
	l=strlen(str);
	for(i=0,j=l-1;i<j;i++,j--)
	{
		temp=str[i];
		str[i]=str[j];
		str[j]=temp;
	}
	return str;
}

// replace the reverse word with matching word
void replace(int *fp,char *ptr)
{
	int l=strlen(ptr);
	lseek(*fp,(-l-1),SEEK_CUR);
	write(*fp,ptr,l);
}

// signal handler
void ouch(int sig)
{


}

// Main function
int main(int argc,char *argv[])
{
	int i=0,ret;
	void * t_result;
	//open an existing file
	fd=open(argv[1],O_RDWR);
	if(fd<0)
	{
		perror("error:");
		exit(0);
	}

	userbuf=argv[2];

	ret=pthread_create(&thread1,NULL,fun,NULL);
	if(ret!=0)
	{
		perror("Error:");
		exit(0);
	}

	ret=pthread_create(&thread2,NULL,fun1,NULL);
	if(ret!=0)
	{
		perror("ERror:");
		exit(0);
	}

	pthread_join(thread1,&t_result);
	pthread_join(thread2,&t_result);
	pthread_exit("EXITSTATUS");
}

void *fun(void *arg)
{

	char store;
	int i=0;
	(void) signal(SIGUSR1,ouch);
	while(read(fd,&store,1)>0)
	{
		if(store!=' ')
		{
			buffer[i]=store;
			i++;
		}

		else
		{	
			i=0;
			pthread_kill(thread2,SIGUSR2);
			sleep(1);
		}
	}

	count=1;
	pthread_exit(NULL);
}

void *fun1(void *arg)
{

	int ret;
	(void) signal(SIGUSR2,ouch);
	while(count!=1)
	{
		ret=stricmp(userbuf,buffer);
		if(ret==0)
		{
			printf("before  reverse buffer :%s\n",buffer);
			revptr=strrev(buffer);
			printf(" after revers revptr : %s\n",revptr);
			replace(&fd,revptr);
		}
		memset(buffer,'\0',sizeof(buffer));
		pthread_kill(thread1,SIGUSR1);
		sleep(1);
	}

	pthread_exit(NULL);
}




